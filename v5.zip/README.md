# GreenNest — Website Concepts

Four design directions for the GreenNest Cleaning & Landscapes website (Nairobi, Kenya). Each is a self-contained static site — no build step, no dependencies beyond Google Fonts (loaded via CDN link in `index.html`).

## Structure

```
greennest-website/
├── v1-organic/        Warm, artisanal direction — woven "nest" motif, drag-to-compare hero
├── v2-brand/           Brand-accurate blue/green, corporate trust-seal direction
├── v4-walkthrough/     Six-chapter scroll narrative through a GreenNest visit
├── v5-flagship/        Premium dark editorial design with a working WhatsApp quote builder
└── README.md
```

Each folder is independent:

```
v1-organic/
├── index.html
├── css/
│   └── style.css
└── js/
    └── main.js
```

## Previewing locally

No server or build tools required. Open any version's `index.html` directly in a browser:

```bash
open v5-flagship/index.html        # macOS
start v5-flagship/index.html       # Windows
xdg-open v5-flagship/index.html    # Linux
```

Or use a simple local server (recommended, avoids any browser file:// quirks):

```bash
cd v5-flagship
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploying with GitHub Pages

1. Push this repo to GitHub.
2. Decide which version is going live, then either:
   - Move that version's contents (`index.html`, `css/`, `js/`) to the repo root, **or**
   - In repo Settings → Pages, set the source folder to the version you want (e.g. `/v5-flagship`) if your plan supports a custom publish directory.
3. GitHub Pages will serve `index.html` automatically once enabled.

## What's different about each version

- **v1 — Organic**: forest green / clay / linen palette, hand-built "nest ring" SVG motif, drag-to-compare before/after hero.
- **v2 — Brand**: matches your actual logo's blue-to-green gradient palette, corporate/facilities-management tone, indoor/outdoor toggle hero, trust-seal strip lifted from your poster's "Why Choose Us" copy.
- **v4 — Walkthrough**: full-screen parallax scroll narrative through a single GreenNest visit, six chapters, recolored to the brand palette, vector illustrations only (no photos).
- **v5 — Flagship**: dark premium editorial layout with a sticky side panel, animated stat counters, and an interactive quote builder that generates a ready-to-send WhatsApp message based on the property type and services you select.

## Notes

- All visuals are hand-coded SVG/CSS — no external image dependencies, so nothing can break from a broken hotlink.
- Contact details (phone, email) are wired to `wa.me` and `mailto:` links throughout — update `254707374749` and `greennest@gmail.com` in each `index.html` if these change.
- Fonts load from Google Fonts via the `<link>` tags in each `index.html`'s `<head>`. For a fully offline-capable build, self-host the font files and update those links.
