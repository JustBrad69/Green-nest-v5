// Before/After slider
  const scene = document.getElementById('scene');
  const handle = document.getElementById('sceneHandle');
  const beforeLayer = scene.querySelector('.scene-before');
  let dragging = false;

  function setSlide(percent){
    percent = Math.max(0, Math.min(100, percent));
    beforeLayer.style.clipPath = `inset(0 ${100-percent}% 0 0)`;
    handle.style.left = percent + '%';
  }
  function fromClientX(clientX){
    const rect = scene.getBoundingClientRect();
    return ((clientX - rect.left) / rect.width) * 100;
  }
  handle.addEventListener('pointerdown', e=>{ dragging = true; e.preventDefault(); });
  window.addEventListener('pointerup', ()=> dragging = false);
  window.addEventListener('pointermove', e=>{
    if(!dragging) return;
    setSlide(fromClientX(e.clientX));
  });
  scene.addEventListener('click', e=>{
    setSlide(fromClientX(e.clientX));
  });
  setSlide(50);

  // gentle auto-demo once on load, then stop (respects reduced motion)
  if(!window.matchMedia('(prefers-reduced-motion: reduce)').matches){
    let p = 50, dir = 1, ticks = 0;
    const demo = setInterval(()=>{
      if(dragging){ clearInterval(demo); return; }
      p += dir * 0.6;
      if(p > 72){ dir = -1; }
      if(p < 28){ dir = 1; }
      setSlide(p);
      ticks++;
      if(ticks > 160){ clearInterval(demo); setSlide(50); }
    }, 30);
  }

  // scroll reveal
  const revealEls = document.querySelectorAll('.reveal');
  const io = new IntersectionObserver(entries=>{
    entries.forEach(en=>{
      if(en.isIntersecting){ en.target.classList.add('in'); io.unobserve(en.target); }
    });
  }, {threshold:.15});
  revealEls.forEach(el=> io.observe(el));